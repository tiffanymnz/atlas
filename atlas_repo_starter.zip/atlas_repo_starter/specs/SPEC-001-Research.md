# SPEC-001 — Research Specification

## Purpose

Produce an evidence-based research dossier for one Atlas concept.

## Required Inputs

- Concept ID
- Subject
- Domain
- Cluster
- Concept title
- Target learner
- Standards or objectives

## Required Outputs

- Definition
- Scope
- Standards alignment
- Common misconceptions
- Language traps
- Learning science notes
- Curriculum comparison
- Visual recommendations
- Open questions
- References

## Quality Rules

- Do not guess.
- Separate evidence from hypothesis.
- Identify uncertainty clearly.
- Prefer authoritative sources.
- Record disagreements between sources.
- Do not copy curriculum language directly.

## Definition of Done

The research record is complete when every required output is present or explicitly marked unresolved.
