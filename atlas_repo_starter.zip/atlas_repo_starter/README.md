# Atlas

Atlas is a research-backed learning system built around one rule:

> One concept exists once. Every lesson, worksheet, quiz, animation, flashcard, teacher guide, and tutor response is generated from the canonical source.

## Core Folders

- `canon/` — canonical concept records
- `genome/` — reusable memory hooks, misconceptions, visuals, language traps, and patterns
- `specs/` — production standards and AI-worker specifications
- `compiler/` — future generation scripts
- `app/` — future student-facing app
- `tests/` — validation checks
- `docs/` — architecture and process documentation
