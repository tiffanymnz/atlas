# Atlas ID System

## Concept IDs

Format:

`SUBJECT-DOMAIN-CLUSTER-0001`

Example:

`MATH-NS-COMP-0001`

Meaning:
- `MATH` = Mathematics
- `NS` = Number Sense
- `COMP` = Comparison
- `0001` = first concept in the cluster

## Genome IDs

- Memory Hooks: `MH-000001`
- Language Traps: `LT-000001`
- Misconceptions: `MC-000001`
- Visuals: `V-000001`
- Animation Primitives: `AN-000001`
- Assessment Patterns: `AP-000001`
