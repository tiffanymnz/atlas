# Atlas Taxonomy v1

## Mathematics
- Number Sense
  - Whole Numbers
  - Place Value
  - Comparing Numbers
  - Rounding
  - Estimation
- Operations
- Fractions & Decimals
- Ratios & Proportions
- Algebra
- Geometry
- Measurement
- Coordinate Plane
- Data & Statistics
- Probability
- Mathematical Reasoning

## Reading
- Vocabulary
- Main Idea
- Supporting Details
- Inference
- Author's Purpose
- Text Structure
- Evidence
- Argument Analysis

## Science
- Life Science
- Physical Science
- Earth & Space
- Scientific Method
- Graph Interpretation
- Experiments
- Data Analysis

## Social Studies
- Civics & Government
- U.S. History
- World History
- Economics
- Geography
- Data Interpretation
