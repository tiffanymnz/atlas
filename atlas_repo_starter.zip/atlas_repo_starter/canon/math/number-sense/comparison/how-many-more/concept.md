---
id: MATH-NS-COMP-0001
title: How Many More?
subject: Mathematics
domain: Number Sense
cluster: Comparison
tier: 1
status: draft
memory_hooks:
  - MH-000001
language_traps:
  - LT-000001
misconceptions:
  - MC-000001
visuals:
  - V-000001
---

# Big Idea

"How many more?" asks for the gap between two quantities.

# Plain English

Compare the two amounts first. Match what they share. The extra part is the answer.

# Plain Spanish

Compara las dos cantidades primero. Empareja lo que tienen en común. La parte extra es la respuesta.

# Worked Example

Maria has 15 pencils. Leo has 9 pencils. How many more pencils does Maria have?

15 - 9 = 6

Maria has 6 more pencils.

# Research Status

Not complete.

# Next Work

- Complete research dossier.
- Compare block stack, bar model, and number line.
- Test memory hook candidates.
