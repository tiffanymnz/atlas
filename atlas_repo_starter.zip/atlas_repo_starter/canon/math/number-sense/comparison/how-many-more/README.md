# MATH-NS-COMP-0001 — How Many More?

This is the first flagship Atlas concept.

## Goal

Prove that the Atlas Method can teach comparison language better than a standard keyword-based explanation.
